/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "2.0.0",
   minimumCompatibleVersion: "2.0.0",
   build: "2.0.0.250",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Rectangle',
            type:'rect',
            rect:['0%','0%','50%','50%','auto','auto'],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy',
            type:'rect',
            rect:['auto','0%','50%','50%','0%','auto'],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy2',
            type:'rect',
            rect:['auto','auto','50%','50%','0%','0%'],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy3',
            type:'rect',
            rect:['0%','auto','50%','50%','auto','0%'],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_RectangleCopy}": [
            ["style", "top", '-50%'],
            ["style", "bottom", 'auto'],
            ["style", "height", '50%'],
            ["style", "right", '-50.01%'],
            ["style", "left", 'auto'],
            ["style", "width", '50.01%']
         ],
         "${_RectangleCopy2}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '-50%'],
            ["style", "height", '50%'],
            ["style", "right", '-50.01%'],
            ["style", "left", 'auto'],
            ["style", "width", '50.01%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '100%'],
            ["style", "height", '100%'],
            ["style", "overflow", 'hidden']
         ],
         "${_Rectangle}": [
            ["style", "height", '50%'],
            ["style", "top", '-50%'],
            ["style", "left", '-50.01%'],
            ["style", "width", '50.01%']
         ],
         "${_RectangleCopy3}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '-50%'],
            ["style", "height", '50%'],
            ["style", "right", 'auto'],
            ["style", "left", '-50%'],
            ["style", "width", '50.01%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 500,
         autoPlay: true,
         timeline: [
            { id: "eid14", tween: [ "style", "${_RectangleCopy2}", "right", '-0.01%', { fromValue: '-50.01%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid16", tween: [ "style", "${_RectangleCopy2}", "bottom", '0%', { fromValue: '-50%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid8", tween: [ "style", "${_Rectangle}", "top", '0%', { fromValue: '-50%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid4", tween: [ "style", "${_RectangleCopy}", "right", '-0.01%', { fromValue: '-50.01%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid2", tween: [ "style", "${_RectangleCopy}", "top", '0%', { fromValue: '-50%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid10", tween: [ "style", "${_RectangleCopy3}", "left", '0%', { fromValue: '-50%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid12", tween: [ "style", "${_RectangleCopy3}", "bottom", '0%', { fromValue: '-50%'}], position: 0, duration: 500, easing: "easeOutCubic" },
            { id: "eid6", tween: [ "style", "${_Rectangle}", "left", '0%', { fromValue: '-50.01%'}], position: 0, duration: 500, easing: "easeOutCubic" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-129434825");
