/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "2.0.0",
   minimumCompatibleVersion: "2.0.0",
   build: "2.0.0.250",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'butterfly',
            type:'rect',
            rect:['84','34','auto','auto','auto','auto'],
            autoOrient:true
         }],
         symbolInstances: [
         {
            id:'butterfly',
            symbolName:'butterfly'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_butterfly}": [
            ["transform", "scaleX", '0.44712'],
            ["transform", "scaleY", '0.44712'],
            ["motion", "location", '52px 361.5px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: true,
         timeline: [
            { id: "eid1", tween: [ "transform", "${_butterfly}", "scaleX", '0.44712', { fromValue: '0.44712'}], position: 0, duration: 0 },
            { id: "eid2", tween: [ "transform", "${_butterfly}", "scaleY", '0.44712', { fromValue: '0.44712'}], position: 0, duration: 0 },
            { id: "eid17", tween: [ "motion", "${_butterfly}", [[52,361.5,0,0],[73.25,137.6,161.89,-117.31,196.22,-142.18],[278.47,61.71,155.97,-29.08,219.99,-41.01],[438.33,139.52,87.77,83.49,143.42,136.42],[442.71,332.52,-27.99,71.76,-76.02,194.91],[220.74,448.67,-266.62,7.42,-289.81,8.07],[61.44,367.67,0,0]]], position: 0, duration: 2000 }         ]
      }
   }
},
"butterfly": {
   version: "2.0.0",
   minimumCompatibleVersion: "2.0.0",
   build: "2.0.0.250",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'body',
      type: 'image',
      rect: ['84px','13px','59px','91px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/body.png','0px','0px']
   },
   {
      rect: ['0px','0px','114px','171px','auto','auto'],
      id: 'left',
      transform: [],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/left.png','0px','0px']
   },
   {
      rect: ['118px','0px','114px','171px','auto','auto'],
      id: 'right',
      transform: [],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/right.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_left}": [
            ["style", "-webkit-transform-origin", [100,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [100,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [100,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [100,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [100,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "width", '114px']
         ],
         "${_right}": [
            ["style", "-webkit-transform-origin", [0,50], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,50],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '0px'],
            ["style", "left", '118px'],
            ["style", "width", '114px']
         ],
         "${_body}": [
            ["style", "left", '84px'],
            ["style", "top", '13px']
         ],
         "${symbolSelector}": [
            ["style", "height", '171px'],
            ["style", "width", '232px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 175,
         autoPlay: true,
         timeline: [
            { id: "eid6", tween: [ "style", "${_left}", "left", '102px', { fromValue: '0px'}], position: 0, duration: 52 },
            { id: "eid10", tween: [ "style", "${_left}", "left", '0px', { fromValue: '102px'}], position: 52, duration: 122 },
            { id: "eid5", tween: [ "style", "${_right}", "width", '9px', { fromValue: '114px'}], position: 0, duration: 52 },
            { id: "eid8", tween: [ "style", "${_right}", "width", '114px', { fromValue: '9px'}], position: 52, duration: 122 },
            { id: "eid7", tween: [ "style", "${_left}", "width", '9px', { fromValue: '114px'}], position: 0, duration: 52 },
            { id: "eid9", tween: [ "style", "${_left}", "width", '114px', { fromValue: '9px'}], position: 52, duration: 122 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-151674503");
